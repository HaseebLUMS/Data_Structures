#include <iostream>

using namespace std;
int main(){
	int i=0;
	if(i++ == 0){
		cout<< i << endl;
	}
	//cout<< i<< endl;
}